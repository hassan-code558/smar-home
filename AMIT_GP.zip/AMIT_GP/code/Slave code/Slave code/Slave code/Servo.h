/*
 * Servo.h
 *
 * Created: 1/7/2024 6:39:02 PM
 *  Author: Hassan
 */ 
#include <avr/io.h>
#include <util/delay.h>
#include "STD_Types.h"
#include "std_macros.h"
#ifndef SERVO_H_
#define SERVO_H_

/*
	Function Name        : Servo_vInit
	Function Returns     : void
	Function Arguments   : void
	Function Description : Initialize the pin as an output pin to connect the Servo.
*/
void Servo_vInit(void);

/*
	Function Name        : Servo_vWrite0
	Function Returns     : void
	Function Arguments   : void
	Function Description : Rotate Motor to 0 degree
*/

void Servo_vWrite0(void);


/*
	Function Name        : Servo_vWrite90
	Function Returns     : void
	Function Arguments   : void
	Function Description : Rotate Motor to 90 degree
*/

void Servo_vWrite90(void);

/*
	Function Name        : Servo_vWrite180
	Function Returns     : void
	Function Arguments   : void
	Function Description : Rotate Motor to 180 degree
*/

void Servo_vWrite180(void);
#endif /* SERVO_H_ */