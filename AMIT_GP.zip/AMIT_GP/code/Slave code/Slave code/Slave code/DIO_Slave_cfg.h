/*
 * DIO_Slave_cfg.h
 *
 * Created: 1/10/2023 11:20:29 AM
 *  Author: Hassan Abdo
 */
 


#ifndef DIO_SLAVE_CFG_H_
#define DIO_SLAVE_CFG_H_
#define ROOM1_LED_PORT			  'D'
#define ROOM2_LED_PORT			  'D'
#define ROOM3_LED_PORT			  'D'
#define ROOM4_LED_PORT			  'D'
#define DOOR_PORT				  'D'
#define AIR_CONDITIONING_LED_PORT 'D'

#define ROOM1_LED_PIN			   0
#define ROOM2_LED_PIN			   1
#define ROOM3_LED_PIN			   2
#define ROOM4_LED_PIN			   3
#define DOOR_PIN				   4
#define AIR_CONDITIONING_LED_PIN   5

#endif /* DIO_SLAVE_CFG_H_ */