/*
 * Servo.c
 *
 * Created: 1/7/2024 6:48:53 PM
 *  Author: Hassan
 */ 
#include "Servo.h"
void Servo_vInit()
{
	/*
	SET_BIT(DDRC , 0);
	*/
	DDRC = 0x01;
	PORTC = 0x00;
}

void Servo_vWrite0()
{
	/*
	SET_BIT(PORTC , 0);
	_delay_us(1000);
	CLR_BIT(PORTC , 0);
	_delay_ms(2000);
	*/
	PORTC = 0x01;
	_delay_us(1000);
	PORTC = 0x00;
	
	_delay_ms(2000);
}

void Servo_vWrite90()
{
	/*
	SET_BIT(PORTC , 0);
	_delay_us(1500);
	CLR_BIT(PORTC , 0);
	_delay_ms(2000);
	*/
	 PORTC = 0x01;
	 _delay_us(1500);
	 PORTC = 0x00;
	 
	 _delay_ms(2000);
}

void Servo_vWrite180()
{
	PORTC = 0x01;
	_delay_us(2000);
	PORTC = 0x00;

	_delay_ms(2000);
}