/*
 * LCD_config.h
 *
 * Created: 9/25/2023 6:00:06 PM
 *  Author: Hassan Abdo
 */ 


#ifndef LCD_CONFIG_H_
#define LCD_CONFIG_H_

#define eight_bits_mode
//#define four_bits_mode

#endif /* LCD_CONFIG_H_ */